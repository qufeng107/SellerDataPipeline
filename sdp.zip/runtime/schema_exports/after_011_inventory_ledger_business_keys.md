# Azure SQL Live Schema Export

> This file is generated from the live Azure SQL system catalog. 
> Use it as an input when updating `docs/database/database_current_schema_spec.md`; 
> it is not a replacement for the curated spec because it does not contain all human field descriptions.

## Database

- Generated at UTC: `2026-05-17T22:26:39.942060+00:00`
- Database: `amazon_ops`
- Server: `amazon-ops-sql`
- Edition: `SQL Azure`
- Login: `sqladminuser`
- User tables: `28`

## Table Summary

| Table | Columns | Indexes | Key constraints | Foreign keys | Row count |
|---|---:|---:|---:|---:|---:|
| `dbo.amazon_ads_profile` | 16 | 3 | 1 | 0 | 0 |
| `dbo.amazon_ads_sp_advertised_product_daily` | 29 | 5 | 1 | 0 | 32 |
| `dbo.amazon_ads_sp_campaign_daily` | 26 | 4 | 1 | 0 | 8 |
| `dbo.amazon_ads_sp_search_term_daily` | 32 | 4 | 1 | 0 | 61 |
| `dbo.amazon_ads_sp_targeting_daily` | 31 | 4 | 1 | 0 | 99 |
| `dbo.amazon_coupon_asin` | 22 | 3 | 1 | 0 | 0 |
| `dbo.amazon_coupon_performance` | 32 | 3 | 1 | 0 | 0 |
| `dbo.amazon_fba_fee_preview` | 46 | 4 | 1 | 0 | 8 |
| `dbo.amazon_fba_reimbursement` | 33 | 4 | 1 | 0 | 19 |
| `dbo.amazon_inventory_daily` | 38 | 4 | 1 | 0 | 5 |
| `dbo.amazon_inventory_ledger_detail` | 31 | 3 | 1 | 0 | 0 |
| `dbo.amazon_inventory_ledger_summary_daily` | 37 | 3 | 1 | 0 | 0 |
| `dbo.amazon_inventory_planning_daily` | 50 | 2 | 1 | 0 | 0 |
| `dbo.amazon_listing_snapshot` | 33 | 4 | 1 | 0 | 6 |
| `dbo.amazon_marketplace` | 10 | 2 | 1 | 0 | 1 |
| `dbo.amazon_order_item` | 47 | 4 | 1 | 0 | 112 |
| `dbo.amazon_promotion_performance` | 28 | 3 | 1 | 0 | 0 |
| `dbo.amazon_promotion_product_performance` | 26 | 3 | 1 | 0 | 0 |
| `dbo.amazon_raw_report_file` | 24 | 4 | 1 | 0 | 0 |
| `dbo.amazon_report_field_catalog` | 17 | 2 | 1 | 0 | 0 |
| `dbo.amazon_report_request` | 22 | 4 | 1 | 0 | 0 |
| `dbo.amazon_reserved_inventory_daily` | 23 | 2 | 1 | 0 | 0 |
| `dbo.amazon_sales_traffic_asin_daily` | 56 | 4 | 1 | 0 | 1 |
| `dbo.amazon_sales_traffic_daily` | 58 | 4 | 1 | 0 | 6 |
| `dbo.amazon_schema_validation_event` | 22 | 3 | 1 | 0 | 36 |
| `dbo.amazon_settlement_transaction` | 42 | 5 | 1 | 0 | 4911 |
| `dbo.amazon_sku_cost` | 14 | 2 | 1 | 0 | 0 |
| `dbo.amazon_sync_run_log` | 27 | 4 | 1 | 0 | 16 |

## Tables

### `dbo.amazon_ads_profile`

- Create date: `2026-05-16T20:29:56.617000`
- Modify date: `2026-05-16T20:30:11.767000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `profile_id` | `NVARCHAR(100)` | NO |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 4 | `country_code` | `NVARCHAR(10)` | YES |  | `` |
| 5 | `currency_code` | `NVARCHAR(10)` | YES |  | `` |
| 6 | `timezone` | `NVARCHAR(100)` | YES |  | `` |
| 7 | `account_id` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `account_type` | `NVARCHAR(100)` | YES |  | `` |
| 9 | `account_name` | `NVARCHAR(500)` | YES |  | `` |
| 10 | `valid_payment_method` | `BIT` | YES |  | `` |
| 11 | `daily_budget` | `DECIMAL(18,4)` | YES |  | `` |
| 12 | `source_system` | `NVARCHAR(50)` | NO |  | `('amazon_ads')` |
| 13 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 14 | `discovered_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 15 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 16 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_ads_profile_marketplace` | NO | `NONCLUSTERED` | `marketplace_id`, `country_code`, `account_type` |  | `` |
| `PK_amazon_ads_profile` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_ads_profile_profile_id` | YES | `NONCLUSTERED` | `profile_id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_ads_profile` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_ads_profile` |

### `dbo.amazon_ads_sp_advertised_product_daily`

- Create date: `2026-05-16T20:29:56.863000`
- Modify date: `2026-05-16T20:30:12.447000`
- Row count: `32`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `profile_id` | `NVARCHAR(100)` | NO |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 4 | `report_date` | `DATE` | NO |  | `` |
| 5 | `campaign_id` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `campaign_name` | `NVARCHAR(500)` | YES |  | `` |
| 7 | `ad_group_id` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `ad_group_name` | `NVARCHAR(500)` | YES |  | `` |
| 9 | `advertised_asin` | `NVARCHAR(50)` | YES |  | `` |
| 10 | `advertised_sku` | `NVARCHAR(200)` | YES |  | `` |
| 11 | `impressions` | `INT` | YES |  | `` |
| 12 | `clicks` | `INT` | YES |  | `` |
| 13 | `cost` | `DECIMAL(18,4)` | YES |  | `` |
| 14 | `sales_7d` | `DECIMAL(18,4)` | YES |  | `` |
| 15 | `purchases_7d` | `INT` | YES |  | `` |
| 16 | `units_sold_clicks_7d` | `INT` | YES |  | `` |
| 17 | `source_system` | `NVARCHAR(50)` | NO |  | `('amazon_ads')` |
| 18 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 19 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 20 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 21 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 22 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 23 | `source_run_id` | `BIGINT` | YES |  | `` |
| 24 | `source_row_index` | `INT` | YES |  | `` |
| 25 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 26 | `business_key_hash` | `NVARCHAR(100)` | NO |  | `` |
| 27 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 28 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 29 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_ads_sp_advertised_product_daily_campaign` | NO | `NONCLUSTERED` | `profile_id`, `campaign_id`, `ad_group_id`, `report_date` DESC |  | `` |
| `IX_amazon_ads_sp_advertised_product_daily_key` | NO | `NONCLUSTERED` | `profile_id`, `report_date` DESC, `advertised_asin`, `advertised_sku` |  | `` |
| `IX_amazon_ads_sp_advertised_product_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_ads_sp_advertised_product_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_ads_sp_advertised_product_daily_business_key` | YES | `NONCLUSTERED` | `business_key_hash` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_ads_sp_advertised_product_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_ads_sp_advertised_product_daily` |

### `dbo.amazon_ads_sp_campaign_daily`

- Create date: `2026-05-16T20:29:56.690000`
- Modify date: `2026-05-16T20:30:11.923000`
- Row count: `8`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `profile_id` | `NVARCHAR(100)` | NO |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 4 | `report_date` | `DATE` | NO |  | `` |
| 5 | `campaign_id` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `campaign_name` | `NVARCHAR(500)` | YES |  | `` |
| 7 | `campaign_status` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `impressions` | `INT` | YES |  | `` |
| 9 | `clicks` | `INT` | YES |  | `` |
| 10 | `cost` | `DECIMAL(18,4)` | YES |  | `` |
| 11 | `sales_7d` | `DECIMAL(18,4)` | YES |  | `` |
| 12 | `purchases_7d` | `INT` | YES |  | `` |
| 13 | `units_sold_clicks_7d` | `INT` | YES |  | `` |
| 14 | `source_system` | `NVARCHAR(50)` | NO |  | `('amazon_ads')` |
| 15 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 16 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 17 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 18 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 19 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 20 | `source_run_id` | `BIGINT` | YES |  | `` |
| 21 | `source_row_index` | `INT` | YES |  | `` |
| 22 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 23 | `business_key_hash` | `NVARCHAR(100)` | NO |  | `` |
| 24 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 25 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 26 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_ads_sp_campaign_daily_key` | NO | `NONCLUSTERED` | `profile_id`, `report_date` DESC, `campaign_id` |  | `` |
| `IX_amazon_ads_sp_campaign_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_ads_sp_campaign_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_ads_sp_campaign_daily_business_key` | YES | `NONCLUSTERED` | `business_key_hash` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_ads_sp_campaign_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_ads_sp_campaign_daily` |

### `dbo.amazon_ads_sp_search_term_daily`

- Create date: `2026-05-16T20:29:56.787000`
- Modify date: `2026-05-16T20:30:12.243000`
- Row count: `61`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `profile_id` | `NVARCHAR(100)` | NO |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 4 | `report_date` | `DATE` | NO |  | `` |
| 5 | `campaign_id` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `campaign_name` | `NVARCHAR(500)` | YES |  | `` |
| 7 | `ad_group_id` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `ad_group_name` | `NVARCHAR(500)` | YES |  | `` |
| 9 | `keyword_id` | `NVARCHAR(100)` | YES |  | `` |
| 10 | `keyword` | `NVARCHAR(500)` | YES |  | `` |
| 11 | `match_type` | `NVARCHAR(100)` | YES |  | `` |
| 12 | `targeting` | `NVARCHAR(1000)` | YES |  | `` |
| 13 | `search_term` | `NVARCHAR(1000)` | YES |  | `` |
| 14 | `impressions` | `INT` | YES |  | `` |
| 15 | `clicks` | `INT` | YES |  | `` |
| 16 | `cost` | `DECIMAL(18,4)` | YES |  | `` |
| 17 | `sales_7d` | `DECIMAL(18,4)` | YES |  | `` |
| 18 | `purchases_7d` | `INT` | YES |  | `` |
| 19 | `units_sold_clicks_7d` | `INT` | YES |  | `` |
| 20 | `source_system` | `NVARCHAR(50)` | NO |  | `('amazon_ads')` |
| 21 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 22 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 23 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 24 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 25 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 26 | `source_run_id` | `BIGINT` | YES |  | `` |
| 27 | `source_row_index` | `INT` | YES |  | `` |
| 28 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 29 | `business_key_hash` | `NVARCHAR(100)` | NO |  | `` |
| 30 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 31 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 32 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_ads_sp_search_term_daily_key` | NO | `NONCLUSTERED` | `profile_id`, `report_date` DESC, `campaign_id`, `ad_group_id`, `keyword_id` |  | `` |
| `IX_amazon_ads_sp_search_term_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_ads_sp_search_term_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_ads_sp_search_term_daily_business_key` | YES | `NONCLUSTERED` | `business_key_hash` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_ads_sp_search_term_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_ads_sp_search_term_daily` |

### `dbo.amazon_ads_sp_targeting_daily`

- Create date: `2026-05-16T20:29:56.737000`
- Modify date: `2026-05-16T20:30:12.087000`
- Row count: `99`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `profile_id` | `NVARCHAR(100)` | NO |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 4 | `report_date` | `DATE` | NO |  | `` |
| 5 | `campaign_id` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `campaign_name` | `NVARCHAR(500)` | YES |  | `` |
| 7 | `ad_group_id` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `ad_group_name` | `NVARCHAR(500)` | YES |  | `` |
| 9 | `keyword_id` | `NVARCHAR(100)` | YES |  | `` |
| 10 | `keyword` | `NVARCHAR(500)` | YES |  | `` |
| 11 | `match_type` | `NVARCHAR(100)` | YES |  | `` |
| 12 | `targeting` | `NVARCHAR(1000)` | YES |  | `` |
| 13 | `impressions` | `INT` | YES |  | `` |
| 14 | `clicks` | `INT` | YES |  | `` |
| 15 | `cost` | `DECIMAL(18,4)` | YES |  | `` |
| 16 | `sales_7d` | `DECIMAL(18,4)` | YES |  | `` |
| 17 | `purchases_7d` | `INT` | YES |  | `` |
| 18 | `units_sold_clicks_7d` | `INT` | YES |  | `` |
| 19 | `source_system` | `NVARCHAR(50)` | NO |  | `('amazon_ads')` |
| 20 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 21 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 22 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 23 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 24 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 25 | `source_run_id` | `BIGINT` | YES |  | `` |
| 26 | `source_row_index` | `INT` | YES |  | `` |
| 27 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 28 | `business_key_hash` | `NVARCHAR(100)` | NO |  | `` |
| 29 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 30 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 31 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_ads_sp_targeting_daily_key` | NO | `NONCLUSTERED` | `profile_id`, `report_date` DESC, `campaign_id`, `ad_group_id`, `keyword_id` |  | `` |
| `IX_amazon_ads_sp_targeting_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_ads_sp_targeting_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_ads_sp_targeting_daily_business_key` | YES | `NONCLUSTERED` | `business_key_hash` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_ads_sp_targeting_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_ads_sp_targeting_daily` |

### `dbo.amazon_coupon_asin`

- Create date: `2026-05-16T20:29:56.553000`
- Modify date: `2026-05-17T22:26:25.940000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 3 | `coupon_id` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `merchant_id` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 6 | `coupon_name` | `NVARCHAR(500)` | YES |  | `` |
| 7 | `currency_code` | `NVARCHAR(10)` | YES |  | `` |
| 8 | `start_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 9 | `end_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 10 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 11 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 12 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 13 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 14 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 15 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 16 | `source_run_id` | `BIGINT` | YES |  | `` |
| 17 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 18 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 19 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 20 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 21 | `source_row_index` | `INT` | YES |  | `` |
| 22 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_coupon_asin_key` | NO | `NONCLUSTERED` | `marketplace_id`, `coupon_id`, `asin` |  | `` |
| `PK_amazon_coupon_asin` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_coupon_asin_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_coupon_asin` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_coupon_asin` |

### `dbo.amazon_coupon_performance`

- Create date: `2026-05-16T20:29:56.493000`
- Modify date: `2026-05-17T22:26:25.800000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 3 | `coupon_id` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `merchant_id` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `currency_code` | `NVARCHAR(10)` | YES |  | `` |
| 6 | `name` | `NVARCHAR(500)` | YES |  | `` |
| 7 | `website_message` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `start_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 9 | `end_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 10 | `discount_type` | `NVARCHAR(100)` | YES |  | `` |
| 11 | `discount_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 12 | `total_discount` | `DECIMAL(18,4)` | YES |  | `` |
| 13 | `clips` | `INT` | YES |  | `` |
| 14 | `redemptions` | `INT` | YES |  | `` |
| 15 | `budget` | `DECIMAL(18,4)` | YES |  | `` |
| 16 | `budget_spent` | `DECIMAL(18,4)` | YES |  | `` |
| 17 | `budget_remaining` | `DECIMAL(18,4)` | YES |  | `` |
| 18 | `budget_percentage_used` | `DECIMAL(18,6)` | YES |  | `` |
| 19 | `sales` | `DECIMAL(18,4)` | YES |  | `` |
| 20 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 21 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 22 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 23 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 24 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 25 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 26 | `source_run_id` | `BIGINT` | YES |  | `` |
| 27 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 28 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 29 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 30 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 31 | `source_row_index` | `INT` | YES |  | `` |
| 32 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_coupon_performance_key` | NO | `NONCLUSTERED` | `marketplace_id`, `coupon_id`, `merchant_id` |  | `` |
| `PK_amazon_coupon_performance` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_coupon_performance_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_coupon_performance` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_coupon_performance` |

### `dbo.amazon_fba_fee_preview`

- Create date: `2026-05-16T20:29:55.980000`
- Modify date: `2026-05-17T22:01:55.100000`
- Row count: `8`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 5 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 6 | `amazon_store` | `NVARCHAR(200)` | YES |  | `` |
| 7 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `product_group` | `NVARCHAR(200)` | YES |  | `` |
| 9 | `brand` | `NVARCHAR(200)` | YES |  | `` |
| 10 | `fulfilled_by` | `NVARCHAR(100)` | YES |  | `` |
| 11 | `your_price` | `DECIMAL(18,4)` | YES |  | `` |
| 12 | `sales_price` | `DECIMAL(18,4)` | YES |  | `` |
| 13 | `longest_side` | `DECIMAL(18,6)` | YES |  | `` |
| 14 | `median_side` | `DECIMAL(18,6)` | YES |  | `` |
| 15 | `shortest_side` | `DECIMAL(18,6)` | YES |  | `` |
| 16 | `length_and_girth` | `DECIMAL(18,6)` | YES |  | `` |
| 17 | `unit_of_dimension` | `NVARCHAR(50)` | YES |  | `` |
| 18 | `item_package_weight` | `DECIMAL(18,6)` | YES |  | `` |
| 19 | `unit_of_weight` | `NVARCHAR(50)` | YES |  | `` |
| 20 | `product_size_tier` | `NVARCHAR(200)` | YES |  | `` |
| 21 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 22 | `estimated_fee_total` | `DECIMAL(18,4)` | YES |  | `` |
| 23 | `estimated_referral_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 24 | `estimated_variable_closing_fee` | `DECIMAL(18,4)` | YES |  | `` |
| 25 | `estimated_order_handling_fee_per_order` | `DECIMAL(18,4)` | YES |  | `` |
| 26 | `estimated_pick_pack_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 27 | `estimated_weight_handling_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 28 | `expected_fulfillment_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 29 | `estimated_future_fee_total` | `DECIMAL(18,4)` | YES |  | `` |
| 30 | `estimated_future_order_handling_fee_per_order` | `DECIMAL(18,4)` | YES |  | `` |
| 31 | `estimated_future_pick_pack_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 32 | `estimated_future_weight_handling_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 33 | `expected_future_fulfillment_fee_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 34 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 35 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 36 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 37 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 38 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 39 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 40 | `source_run_id` | `BIGINT` | YES |  | `` |
| 41 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 42 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 43 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 44 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 45 | `source_row_index` | `INT` | YES |  | `` |
| 46 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_fba_fee_preview_sku` | NO | `NONCLUSTERED` | `marketplace_id`, `seller_sku`, `fnsku`, `asin` |  | `` |
| `IX_amazon_fba_fee_preview_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_fba_fee_preview` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_fba_fee_preview_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_fba_fee_preview` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_fba_fee_preview` |

### `dbo.amazon_fba_reimbursement`

- Create date: `2026-05-16T20:29:55.803000`
- Modify date: `2026-05-17T21:41:46.037000`
- Row count: `19`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `approval_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 4 | `reimbursement_id` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `case_id` | `NVARCHAR(200)` | YES |  | `` |
| 6 | `amazon_order_id` | `NVARCHAR(200)` | YES |  | `` |
| 7 | `reason` | `NVARCHAR(300)` | YES |  | `` |
| 8 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 9 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 10 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 11 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 12 | `condition` | `NVARCHAR(50)` | YES |  | `` |
| 13 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 14 | `amount_per_unit` | `DECIMAL(18,4)` | YES |  | `` |
| 15 | `amount_total` | `DECIMAL(18,4)` | YES |  | `` |
| 16 | `quantity_reimbursed_cash` | `INT` | YES |  | `` |
| 17 | `quantity_reimbursed_inventory` | `INT` | YES |  | `` |
| 18 | `quantity_reimbursed_total` | `INT` | YES |  | `` |
| 19 | `original_reimbursement_id` | `NVARCHAR(200)` | YES |  | `` |
| 20 | `original_reimbursement_type` | `NVARCHAR(100)` | YES |  | `` |
| 21 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 22 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 23 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 24 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 25 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 26 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 27 | `source_run_id` | `BIGINT` | YES |  | `` |
| 28 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 29 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 30 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 31 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 32 | `source_row_index` | `INT` | YES |  | `` |
| 33 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_fba_reimbursement_key` | NO | `NONCLUSTERED` | `marketplace_id`, `reimbursement_id`, `case_id`, `seller_sku`, `asin` |  | `` |
| `IX_amazon_fba_reimbursement_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_fba_reimbursement` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_fba_reimbursement_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_fba_reimbursement` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_fba_reimbursement` |

### `dbo.amazon_inventory_daily`

- Create date: `2026-05-16T20:29:55.463000`
- Modify date: `2026-05-17T20:05:14.293000`
- Row count: `5`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `snapshot_date` | `DATE` | NO |  | `` |
| 4 | `seller_sku` | `NVARCHAR(200)` | NO |  | `` |
| 5 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 7 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `condition` | `NVARCHAR(50)` | YES |  | `` |
| 9 | `your_price` | `DECIMAL(18,4)` | YES |  | `` |
| 10 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 11 | `mfn_listing_exists` | `BIT` | YES |  | `` |
| 12 | `mfn_fulfillable_quantity` | `INT` | YES |  | `` |
| 13 | `afn_listing_exists` | `BIT` | YES |  | `` |
| 14 | `afn_warehouse_quantity` | `INT` | YES |  | `` |
| 15 | `afn_fulfillable_quantity` | `INT` | YES |  | `` |
| 16 | `afn_unsellable_quantity` | `INT` | YES |  | `` |
| 17 | `afn_reserved_quantity` | `INT` | YES |  | `` |
| 18 | `afn_total_quantity` | `INT` | YES |  | `` |
| 19 | `per_unit_volume` | `DECIMAL(18,6)` | YES |  | `` |
| 20 | `afn_inbound_working_quantity` | `INT` | YES |  | `` |
| 21 | `afn_inbound_shipped_quantity` | `INT` | YES |  | `` |
| 22 | `afn_inbound_receiving_quantity` | `INT` | YES |  | `` |
| 23 | `afn_researching_quantity` | `INT` | YES |  | `` |
| 24 | `afn_reserved_future_supply` | `INT` | YES |  | `` |
| 25 | `afn_future_supply_buyable` | `INT` | YES |  | `` |
| 26 | `store` | `NVARCHAR(200)` | YES |  | `` |
| 27 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 28 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 29 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 30 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 31 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 32 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 33 | `source_run_id` | `BIGINT` | YES |  | `` |
| 34 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 35 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 36 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 37 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 38 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_inventory_daily_key` | NO | `NONCLUSTERED` | `marketplace_id`, `snapshot_date` DESC, `seller_sku`, `fnsku`, `asin` |  | `` |
| `IX_amazon_inventory_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_inventory_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_inventory_daily_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_inventory_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_inventory_daily` |

### `dbo.amazon_inventory_ledger_detail`

- Create date: `2026-05-16T20:29:56.140000`
- Modify date: `2026-05-17T22:26:40.980000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `ledger_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 4 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 5 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 6 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 7 | `title` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `event_type` | `NVARCHAR(200)` | YES |  | `` |
| 9 | `reference_id` | `NVARCHAR(300)` | YES |  | `` |
| 10 | `quantity` | `INT` | YES |  | `` |
| 11 | `fulfillment_center` | `NVARCHAR(100)` | YES |  | `` |
| 12 | `disposition` | `NVARCHAR(100)` | YES |  | `` |
| 13 | `reason` | `NVARCHAR(300)` | YES |  | `` |
| 14 | `country` | `NVARCHAR(50)` | YES |  | `` |
| 15 | `reconciled_quantity` | `INT` | YES |  | `` |
| 16 | `unreconciled_quantity` | `INT` | YES |  | `` |
| 17 | `date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 18 | `store` | `NVARCHAR(200)` | YES |  | `` |
| 19 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 20 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 21 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 22 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 23 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 24 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 25 | `source_run_id` | `BIGINT` | YES |  | `` |
| 26 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 27 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 28 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 29 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 30 | `source_row_index` | `INT` | YES |  | `` |
| 31 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_inventory_ledger_detail_key` | NO | `NONCLUSTERED` | `marketplace_id`, `seller_sku`, `fnsku`, `asin`, `event_type`, `reference_id` |  | `` |
| `PK_amazon_inventory_ledger_detail` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_inventory_ledger_detail_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_inventory_ledger_detail` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_inventory_ledger_detail` |

### `dbo.amazon_inventory_ledger_summary_daily`

- Create date: `2026-05-16T20:29:56.037000`
- Modify date: `2026-05-17T22:26:40.847000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `ledger_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 4 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 5 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 6 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 7 | `title` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `disposition` | `NVARCHAR(100)` | YES |  | `` |
| 9 | `starting_warehouse_balance` | `INT` | YES |  | `` |
| 10 | `in_transit_between_warehouses` | `INT` | YES |  | `` |
| 11 | `receipts` | `INT` | YES |  | `` |
| 12 | `customer_shipments` | `INT` | YES |  | `` |
| 13 | `customer_returns` | `INT` | YES |  | `` |
| 14 | `vendor_returns` | `INT` | YES |  | `` |
| 15 | `warehouse_transfer_in_out` | `INT` | YES |  | `` |
| 16 | `found` | `INT` | YES |  | `` |
| 17 | `lost` | `INT` | YES |  | `` |
| 18 | `damaged` | `INT` | YES |  | `` |
| 19 | `disposed` | `INT` | YES |  | `` |
| 20 | `other_events` | `INT` | YES |  | `` |
| 21 | `ending_warehouse_balance` | `INT` | YES |  | `` |
| 22 | `unknown_events` | `INT` | YES |  | `` |
| 23 | `location` | `NVARCHAR(100)` | YES |  | `` |
| 24 | `store` | `NVARCHAR(200)` | YES |  | `` |
| 25 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 26 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 27 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 28 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 29 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 30 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 31 | `source_run_id` | `BIGINT` | YES |  | `` |
| 32 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 33 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 34 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 35 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 36 | `source_row_index` | `INT` | YES |  | `` |
| 37 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_inventory_ledger_summary_daily_key` | NO | `NONCLUSTERED` | `marketplace_id`, `seller_sku`, `fnsku`, `asin`, `ledger_date_raw` |  | `` |
| `PK_amazon_inventory_ledger_summary_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_inventory_ledger_summary_daily_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_inventory_ledger_summary_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_inventory_ledger_summary_daily` |

### `dbo.amazon_inventory_planning_daily`

- Create date: `2026-05-16T20:29:56.293000`
- Modify date: `2026-05-16T20:30:11.390000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `snapshot_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 4 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 7 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `condition` | `NVARCHAR(50)` | YES |  | `` |
| 9 | `available_quantity` | `INT` | YES |  | `` |
| 10 | `pending_removal_quantity` | `INT` | YES |  | `` |
| 11 | `inv_age_0_to_90_days` | `INT` | YES |  | `` |
| 12 | `inv_age_91_to_180_days` | `INT` | YES |  | `` |
| 13 | `inv_age_181_to_270_days` | `INT` | YES |  | `` |
| 14 | `inv_age_271_to_365_days` | `INT` | YES |  | `` |
| 15 | `inv_age_366_to_455_days` | `INT` | YES |  | `` |
| 16 | `inv_age_456_plus_days` | `INT` | YES |  | `` |
| 17 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 18 | `units_shipped_t7` | `INT` | YES |  | `` |
| 19 | `units_shipped_t30` | `INT` | YES |  | `` |
| 20 | `units_shipped_t60` | `INT` | YES |  | `` |
| 21 | `units_shipped_t90` | `INT` | YES |  | `` |
| 22 | `alert` | `NVARCHAR(300)` | YES |  | `` |
| 23 | `your_price` | `DECIMAL(18,4)` | YES |  | `` |
| 24 | `sales_price` | `DECIMAL(18,4)` | YES |  | `` |
| 25 | `recommended_action` | `NVARCHAR(500)` | YES |  | `` |
| 26 | `recommended_sales_price` | `DECIMAL(18,4)` | YES |  | `` |
| 27 | `recommended_sale_duration_days` | `INT` | YES |  | `` |
| 28 | `recommended_removal_quantity` | `INT` | YES |  | `` |
| 29 | `estimated_cost_savings_of_recommended_actions` | `DECIMAL(18,4)` | YES |  | `` |
| 30 | `sell_through` | `DECIMAL(18,6)` | YES |  | `` |
| 31 | `item_volume` | `DECIMAL(18,6)` | YES |  | `` |
| 32 | `volume_unit_measurement` | `NVARCHAR(50)` | YES |  | `` |
| 33 | `storage_type` | `NVARCHAR(100)` | YES |  | `` |
| 34 | `storage_volume` | `DECIMAL(18,6)` | YES |  | `` |
| 35 | `marketplace_name` | `NVARCHAR(200)` | YES |  | `` |
| 36 | `product_group` | `NVARCHAR(200)` | YES |  | `` |
| 37 | `sales_rank` | `INT` | YES |  | `` |
| 38 | `days_of_supply` | `DECIMAL(18,6)` | YES |  | `` |
| 39 | `estimated_excess_quantity` | `INT` | YES |  | `` |
| 40 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 41 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 42 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 43 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 44 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 45 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 46 | `source_run_id` | `BIGINT` | YES |  | `` |
| 47 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 48 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 49 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 50 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_inventory_planning_daily_key` | NO | `NONCLUSTERED` | `marketplace_id`, `seller_sku`, `fnsku`, `asin`, `snapshot_date_raw` |  | `` |
| `PK_amazon_inventory_planning_daily` | YES | `CLUSTERED` | `id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_inventory_planning_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_inventory_planning_daily` |

### `dbo.amazon_listing_snapshot`

- Create date: `2026-05-16T20:29:55.400000`
- Modify date: `2026-05-16T22:22:31.310000`
- Row count: `6`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `snapshot_date` | `DATE` | NO |  | `` |
| 4 | `listing_id` | `NVARCHAR(200)` | NO |  | `` |
| 5 | `seller_sku` | `NVARCHAR(200)` | NO |  | `` |
| 6 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 7 | `product_id` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `product_id_type` | `NVARCHAR(50)` | YES |  | `` |
| 9 | `item_name` | `NVARCHAR(1000)` | YES |  | `` |
| 10 | `item_description` | `NVARCHAR(MAX)` | YES |  | `` |
| 11 | `price` | `DECIMAL(18,4)` | YES |  | `` |
| 12 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 13 | `quantity` | `INT` | YES |  | `` |
| 14 | `pending_quantity` | `INT` | YES |  | `` |
| 15 | `open_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 16 | `open_date_utc` | `DATETIME2(7)` | YES |  | `` |
| 17 | `item_is_marketplace` | `BIT` | YES |  | `` |
| 18 | `item_condition` | `NVARCHAR(50)` | YES |  | `` |
| 19 | `fulfillment_channel` | `NVARCHAR(100)` | YES |  | `` |
| 20 | `merchant_shipping_group` | `NVARCHAR(200)` | YES |  | `` |
| 21 | `status` | `NVARCHAR(50)` | YES |  | `` |
| 22 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 23 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 24 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 25 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 26 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 27 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 28 | `source_run_id` | `BIGINT` | YES |  | `` |
| 29 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 30 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 31 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 32 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 33 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_listing_snapshot_key` | NO | `NONCLUSTERED` | `marketplace_id`, `snapshot_date` DESC, `seller_sku`, `listing_id` |  | `` |
| `IX_amazon_listing_snapshot_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_listing_snapshot` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_listing_snapshot_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_listing_snapshot` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_listing_snapshot` |

### `dbo.amazon_marketplace`

- Create date: `2026-05-16T20:29:54.830000`
- Modify date: `2026-05-16T20:30:09.347000`
- Row count: `1`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `marketplace_name` | `NVARCHAR(200)` | NO |  | `` |
| 4 | `country_code` | `NVARCHAR(10)` | NO |  | `` |
| 5 | `currency` | `NVARCHAR(10)` | NO |  | `` |
| 6 | `region` | `NVARCHAR(20)` | NO |  | `` |
| 7 | `endpoint` | `NVARCHAR(300)` | NO |  | `` |
| 8 | `is_active` | `BIT` | NO |  | `((1))` |
| 9 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 10 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `PK_amazon_marketplace` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_marketplace_marketplace_id` | YES | `NONCLUSTERED` | `marketplace_id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_marketplace` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_marketplace` |

### `dbo.amazon_order_item`

- Create date: `2026-05-16T20:29:55.747000`
- Modify date: `2026-05-17T21:24:56.203000`
- Row count: `112`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `amazon_order_id` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `merchant_order_id` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `purchase_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `last_updated_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 7 | `order_status` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `fulfillment_channel` | `NVARCHAR(100)` | YES |  | `` |
| 9 | `sales_channel` | `NVARCHAR(100)` | YES |  | `` |
| 10 | `order_channel` | `NVARCHAR(100)` | YES |  | `` |
| 11 | `ship_service_level` | `NVARCHAR(100)` | YES |  | `` |
| 12 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 13 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 14 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 15 | `item_status` | `NVARCHAR(100)` | YES |  | `` |
| 16 | `quantity` | `INT` | YES |  | `` |
| 17 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 18 | `item_price` | `DECIMAL(18,4)` | YES |  | `` |
| 19 | `item_tax` | `DECIMAL(18,4)` | YES |  | `` |
| 20 | `shipping_price` | `DECIMAL(18,4)` | YES |  | `` |
| 21 | `shipping_tax` | `DECIMAL(18,4)` | YES |  | `` |
| 22 | `gift_wrap_price` | `DECIMAL(18,4)` | YES |  | `` |
| 23 | `gift_wrap_tax` | `DECIMAL(18,4)` | YES |  | `` |
| 24 | `item_promotion_discount` | `DECIMAL(18,4)` | YES |  | `` |
| 25 | `ship_promotion_discount` | `DECIMAL(18,4)` | YES |  | `` |
| 26 | `ship_city` | `NVARCHAR(200)` | YES |  | `` |
| 27 | `ship_state` | `NVARCHAR(100)` | YES |  | `` |
| 28 | `ship_postal_code` | `NVARCHAR(50)` | YES |  | `` |
| 29 | `ship_country` | `NVARCHAR(50)` | YES |  | `` |
| 30 | `promotion_ids` | `NVARCHAR(1000)` | YES |  | `` |
| 31 | `is_business_order` | `BIT` | YES |  | `` |
| 32 | `purchase_order_number` | `NVARCHAR(200)` | YES |  | `` |
| 33 | `price_designation` | `NVARCHAR(100)` | YES |  | `` |
| 34 | `signature_confirmation_recommended` | `BIT` | YES |  | `` |
| 35 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 36 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 37 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 38 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 39 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 40 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 41 | `source_run_id` | `BIGINT` | YES |  | `` |
| 42 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 43 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 44 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 45 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 46 | `source_row_index` | `INT` | YES |  | `` |
| 47 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_order_item_order_sku` | NO | `NONCLUSTERED` | `marketplace_id`, `amazon_order_id`, `seller_sku`, `asin` |  | `` |
| `IX_amazon_order_item_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_order_item` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_order_item_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_order_item` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_order_item` |

### `dbo.amazon_promotion_performance`

- Create date: `2026-05-16T20:29:56.353000`
- Modify date: `2026-05-17T22:26:25.520000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 3 | `promotion_id` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `merchant_id` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `promotion_name` | `NVARCHAR(500)` | YES |  | `` |
| 6 | `promotion_type` | `NVARCHAR(100)` | YES |  | `` |
| 7 | `status` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `glance_views` | `INT` | YES |  | `` |
| 9 | `units_sold` | `INT` | YES |  | `` |
| 10 | `revenue` | `DECIMAL(18,4)` | YES |  | `` |
| 11 | `revenue_currency_code` | `NVARCHAR(10)` | YES |  | `` |
| 12 | `start_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 13 | `end_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 14 | `created_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 15 | `last_updated_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 16 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 17 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 18 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 19 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 20 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 21 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 22 | `source_run_id` | `BIGINT` | YES |  | `` |
| 23 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 24 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 25 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 26 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 27 | `source_row_index` | `INT` | YES |  | `` |
| 28 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_promotion_performance_key` | NO | `NONCLUSTERED` | `marketplace_id`, `promotion_id`, `status` |  | `` |
| `PK_amazon_promotion_performance` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_promotion_performance_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_promotion_performance` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_promotion_performance` |

### `dbo.amazon_promotion_product_performance`

- Create date: `2026-05-16T20:29:56.440000`
- Modify date: `2026-05-17T22:26:25.670000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 3 | `promotion_id` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `merchant_id` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `promotion_name` | `NVARCHAR(500)` | YES |  | `` |
| 6 | `promotion_type` | `NVARCHAR(100)` | YES |  | `` |
| 7 | `status` | `NVARCHAR(100)` | YES |  | `` |
| 8 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 9 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 10 | `product_glance_views` | `INT` | YES |  | `` |
| 11 | `product_units_sold` | `INT` | YES |  | `` |
| 12 | `product_revenue` | `DECIMAL(18,4)` | YES |  | `` |
| 13 | `product_revenue_currency_code` | `NVARCHAR(10)` | YES |  | `` |
| 14 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 15 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 16 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 17 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 18 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 19 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 20 | `source_run_id` | `BIGINT` | YES |  | `` |
| 21 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 22 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 23 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 24 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 25 | `source_row_index` | `INT` | YES |  | `` |
| 26 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_promotion_product_performance_key` | NO | `NONCLUSTERED` | `marketplace_id`, `promotion_id`, `asin` |  | `` |
| `PK_amazon_promotion_product_performance` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_promotion_product_performance_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_promotion_product_performance` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_promotion_product_performance` |

### `dbo.amazon_raw_report_file`

- Create date: `2026-05-16T20:29:55.077000`
- Modify date: `2026-05-16T20:30:09.867000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `report_request_id` | `BIGINT` | YES |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 4 | `source_system` | `NVARCHAR(50)` | NO |  | `` |
| 5 | `report_type` | `NVARCHAR(120)` | NO |  | `` |
| 6 | `report_id` | `NVARCHAR(120)` | YES |  | `` |
| 7 | `report_document_id` | `NVARCHAR(120)` | YES |  | `` |
| 8 | `file_role` | `NVARCHAR(50)` | NO |  | `('raw')` |
| 9 | `storage_backend` | `NVARCHAR(50)` | NO |  | `('local')` |
| 10 | `file_path` | `NVARCHAR(700)` | NO |  | `` |
| 11 | `file_name` | `NVARCHAR(300)` | NO |  | `` |
| 12 | `file_extension` | `NVARCHAR(30)` | YES |  | `` |
| 13 | `content_type` | `NVARCHAR(200)` | YES |  | `` |
| 14 | `compression_algorithm` | `NVARCHAR(50)` | YES |  | `` |
| 15 | `encoding` | `NVARCHAR(80)` | YES |  | `` |
| 16 | `delimiter` | `NVARCHAR(20)` | YES |  | `` |
| 17 | `row_count` | `INT` | YES |  | `` |
| 18 | `column_count` | `INT` | YES |  | `` |
| 19 | `sha256` | `NVARCHAR(100)` | YES |  | `` |
| 20 | `byte_size` | `BIGINT` | YES |  | `` |
| 21 | `downloaded_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 22 | `source_run_id` | `BIGINT` | YES |  | `` |
| 23 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 24 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_raw_report_file_report` | NO | `NONCLUSTERED` | `source_system`, `report_type`, `marketplace_id`, `downloaded_at` DESC |  | `` |
| `IX_amazon_raw_report_file_sha256` | NO | `NONCLUSTERED` | `sha256` |  | `` |
| `PK_amazon_raw_report_file` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_raw_report_file_path` | YES | `NONCLUSTERED` | `storage_backend`, `file_path` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_raw_report_file` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_raw_report_file` |

### `dbo.amazon_report_field_catalog`

- Create date: `2026-05-16T20:29:55.180000`
- Modify date: `2026-05-16T20:30:09.917000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `source_system` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `report_type` | `NVARCHAR(120)` | NO |  | `` |
| 4 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 5 | `sample_file_id` | `BIGINT` | YES |  | `` |
| 6 | `field_position` | `INT` | YES |  | `` |
| 7 | `source_field_name` | `NVARCHAR(300)` | NO |  | `` |
| 8 | `normalized_field_name` | `NVARCHAR(200)` | YES |  | `` |
| 9 | `target_table` | `NVARCHAR(200)` | YES |  | `` |
| 10 | `target_column` | `NVARCHAR(200)` | YES |  | `` |
| 11 | `data_type_suggestion` | `NVARCHAR(100)` | YES |  | `` |
| 12 | `nullable_observed` | `BIT` | YES |  | `` |
| 13 | `sample_values_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 14 | `field_status` | `NVARCHAR(50)` | NO |  | `('observed')` |
| 15 | `notes` | `NVARCHAR(MAX)` | YES |  | `` |
| 16 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 17 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_report_field_catalog_report` | NO | `NONCLUSTERED` | `source_system`, `report_type`, `marketplace_id`, `field_position` |  | `` |
| `PK_amazon_report_field_catalog` | YES | `CLUSTERED` | `id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_report_field_catalog` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_report_field_catalog` |

### `dbo.amazon_report_request`

- Create date: `2026-05-16T20:29:54.967000`
- Modify date: `2026-05-16T20:30:09.693000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `source_system` | `NVARCHAR(50)` | NO |  | `` |
| 4 | `report_type` | `NVARCHAR(120)` | NO |  | `` |
| 5 | `report_options_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 6 | `data_start_time` | `DATETIME2(7)` | YES |  | `` |
| 7 | `data_end_time` | `DATETIME2(7)` | YES |  | `` |
| 8 | `report_id` | `NVARCHAR(120)` | YES |  | `` |
| 9 | `report_document_id` | `NVARCHAR(120)` | YES |  | `` |
| 10 | `processing_status` | `NVARCHAR(50)` | NO |  | `('SUBMITTED')` |
| 11 | `download_status` | `NVARCHAR(50)` | NO |  | `('PENDING')` |
| 12 | `parse_status` | `NVARCHAR(50)` | NO |  | `('PENDING')` |
| 13 | `requested_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 14 | `last_checked_at` | `DATETIME2(7)` | YES |  | `` |
| 15 | `completed_at` | `DATETIME2(7)` | YES |  | `` |
| 16 | `downloaded_at` | `DATETIME2(7)` | YES |  | `` |
| 17 | `parsed_at` | `DATETIME2(7)` | YES |  | `` |
| 18 | `retry_count` | `INT` | NO |  | `((0))` |
| 19 | `source_run_id` | `BIGINT` | YES |  | `` |
| 20 | `error_message` | `NVARCHAR(MAX)` | YES |  | `` |
| 21 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 22 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_report_request_status` | NO | `NONCLUSTERED` | `processing_status`, `download_status`, `parse_status`, `requested_at` DESC |  | `` |
| `IX_amazon_report_request_type_range` | NO | `NONCLUSTERED` | `source_system`, `report_type`, `marketplace_id`, `data_start_time`, `data_end_time` |  | `` |
| `PK_amazon_report_request` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_report_request_report_id` | YES | `NONCLUSTERED` | `marketplace_id`, `source_system`, `report_type`, `report_id` |  | `([report_id] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_report_request` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_report_request` |

### `dbo.amazon_reserved_inventory_daily`

- Create date: `2026-05-16T20:29:56.200000`
- Modify date: `2026-05-16T20:30:11.343000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `snapshot_date` | `DATE` | NO |  | `(CONVERT([date],sysutcdatetime()))` |
| 4 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 5 | `fnsku` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 7 | `product_name` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `reserved_quantity` | `INT` | YES |  | `` |
| 9 | `reserved_customer_orders` | `INT` | YES |  | `` |
| 10 | `reserved_fc_transfers` | `INT` | YES |  | `` |
| 11 | `reserved_fc_processing` | `INT` | YES |  | `` |
| 12 | `program` | `NVARCHAR(100)` | YES |  | `` |
| 13 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 14 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 15 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 16 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 17 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 18 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 19 | `source_run_id` | `BIGINT` | YES |  | `` |
| 20 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 21 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 22 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 23 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_reserved_inventory_daily_key` | NO | `NONCLUSTERED` | `marketplace_id`, `snapshot_date` DESC, `seller_sku`, `fnsku`, `asin` |  | `` |
| `PK_amazon_reserved_inventory_daily` | YES | `CLUSTERED` | `id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_reserved_inventory_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_reserved_inventory_daily` |

### `dbo.amazon_sales_traffic_asin_daily`

- Create date: `2026-05-16T20:29:55.640000`
- Modify date: `2026-05-17T20:22:47.360000`
- Row count: `1`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `report_start_date` | `DATE` | YES |  | `` |
| 4 | `report_end_date` | `DATE` | YES |  | `` |
| 5 | `parent_asin` | `NVARCHAR(50)` | YES |  | `` |
| 6 | `child_asin` | `NVARCHAR(50)` | YES |  | `` |
| 7 | `date_granularity` | `NVARCHAR(50)` | YES |  | `` |
| 8 | `asin_granularity` | `NVARCHAR(50)` | YES |  | `` |
| 9 | `ordered_product_sales_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 10 | `ordered_product_sales_currency` | `NVARCHAR(10)` | YES |  | `` |
| 11 | `ordered_product_sales_b2b_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 12 | `ordered_product_sales_b2b_currency` | `NVARCHAR(10)` | YES |  | `` |
| 13 | `units_ordered` | `INT` | YES |  | `` |
| 14 | `units_ordered_b2b` | `INT` | YES |  | `` |
| 15 | `total_order_items` | `INT` | YES |  | `` |
| 16 | `total_order_items_b2b` | `INT` | YES |  | `` |
| 17 | `browser_page_views` | `INT` | YES |  | `` |
| 18 | `browser_page_views_b2b` | `INT` | YES |  | `` |
| 19 | `browser_page_views_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 20 | `browser_page_views_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 21 | `mobile_app_page_views` | `INT` | YES |  | `` |
| 22 | `mobile_app_page_views_b2b` | `INT` | YES |  | `` |
| 23 | `mobile_app_page_views_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 24 | `mobile_app_page_views_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 25 | `page_views` | `INT` | YES |  | `` |
| 26 | `page_views_b2b` | `INT` | YES |  | `` |
| 27 | `page_views_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 28 | `page_views_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 29 | `browser_sessions` | `INT` | YES |  | `` |
| 30 | `browser_sessions_b2b` | `INT` | YES |  | `` |
| 31 | `browser_session_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 32 | `browser_session_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 33 | `mobile_app_sessions` | `INT` | YES |  | `` |
| 34 | `mobile_app_sessions_b2b` | `INT` | YES |  | `` |
| 35 | `mobile_app_session_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 36 | `mobile_app_session_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 37 | `sessions` | `INT` | YES |  | `` |
| 38 | `sessions_b2b` | `INT` | YES |  | `` |
| 39 | `session_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 40 | `session_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 41 | `buy_box_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 42 | `buy_box_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 43 | `unit_session_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 44 | `unit_session_percentage_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 45 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 46 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 47 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 48 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 49 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 50 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 51 | `source_run_id` | `BIGINT` | YES |  | `` |
| 52 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 53 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 54 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 55 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 56 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_sales_traffic_asin_daily_key` | NO | `NONCLUSTERED` | `marketplace_id`, `report_start_date` DESC, `report_end_date` DESC, `parent_asin`, `child_asin` |  | `` |
| `IX_amazon_sales_traffic_asin_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_sales_traffic_asin_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_sales_traffic_asin_daily_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_sales_traffic_asin_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_sales_traffic_asin_daily` |

### `dbo.amazon_sales_traffic_daily`

- Create date: `2026-05-16T20:29:55.523000`
- Modify date: `2026-05-17T20:22:47.307000`
- Row count: `6`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `report_date` | `DATE` | NO |  | `` |
| 4 | `date_granularity` | `NVARCHAR(50)` | YES |  | `` |
| 5 | `asin_granularity` | `NVARCHAR(50)` | YES |  | `` |
| 6 | `ordered_product_sales_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 7 | `ordered_product_sales_currency` | `NVARCHAR(10)` | YES |  | `` |
| 8 | `ordered_product_sales_b2b_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 9 | `ordered_product_sales_b2b_currency` | `NVARCHAR(10)` | YES |  | `` |
| 10 | `average_sales_per_order_item_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 11 | `average_sales_per_order_item_currency` | `NVARCHAR(10)` | YES |  | `` |
| 12 | `average_sales_per_order_item_b2b_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 13 | `average_sales_per_order_item_b2b_currency` | `NVARCHAR(10)` | YES |  | `` |
| 14 | `average_units_per_order_item` | `DECIMAL(18,6)` | YES |  | `` |
| 15 | `average_units_per_order_item_b2b` | `DECIMAL(18,6)` | YES |  | `` |
| 16 | `average_selling_price_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 17 | `average_selling_price_currency` | `NVARCHAR(10)` | YES |  | `` |
| 18 | `average_selling_price_b2b_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 19 | `average_selling_price_b2b_currency` | `NVARCHAR(10)` | YES |  | `` |
| 20 | `units_ordered` | `INT` | YES |  | `` |
| 21 | `units_ordered_b2b` | `INT` | YES |  | `` |
| 22 | `total_order_items` | `INT` | YES |  | `` |
| 23 | `total_order_items_b2b` | `INT` | YES |  | `` |
| 24 | `units_refunded` | `INT` | YES |  | `` |
| 25 | `refund_rate` | `DECIMAL(18,6)` | YES |  | `` |
| 26 | `claims_granted` | `INT` | YES |  | `` |
| 27 | `claims_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 28 | `claims_amount_currency` | `NVARCHAR(10)` | YES |  | `` |
| 29 | `shipped_product_sales_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 30 | `shipped_product_sales_currency` | `NVARCHAR(10)` | YES |  | `` |
| 31 | `units_shipped` | `INT` | YES |  | `` |
| 32 | `orders_shipped` | `INT` | YES |  | `` |
| 33 | `browser_page_views` | `INT` | YES |  | `` |
| 34 | `mobile_app_page_views` | `INT` | YES |  | `` |
| 35 | `page_views` | `INT` | YES |  | `` |
| 36 | `browser_sessions` | `INT` | YES |  | `` |
| 37 | `mobile_app_sessions` | `INT` | YES |  | `` |
| 38 | `sessions` | `INT` | YES |  | `` |
| 39 | `buy_box_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 40 | `order_item_session_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 41 | `unit_session_percentage` | `DECIMAL(18,6)` | YES |  | `` |
| 42 | `average_offer_count` | `DECIMAL(18,6)` | YES |  | `` |
| 43 | `average_parent_items` | `DECIMAL(18,6)` | YES |  | `` |
| 44 | `feedback_received` | `INT` | YES |  | `` |
| 45 | `negative_feedback_received` | `INT` | YES |  | `` |
| 46 | `received_negative_feedback_rate` | `DECIMAL(18,6)` | YES |  | `` |
| 47 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 48 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 49 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 50 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 51 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 52 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 53 | `source_run_id` | `BIGINT` | YES |  | `` |
| 54 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 55 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 56 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 57 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 58 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_sales_traffic_daily_date` | NO | `NONCLUSTERED` | `marketplace_id`, `report_date` DESC |  | `` |
| `IX_amazon_sales_traffic_daily_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_sales_traffic_daily` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_sales_traffic_daily_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_sales_traffic_daily` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_sales_traffic_daily` |

### `dbo.amazon_schema_validation_event`

- Create date: `2026-05-16T20:29:55.257000`
- Modify date: `2026-05-16T20:30:10.150000`
- Row count: `36`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `source_system` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 4 | `report_type` | `NVARCHAR(120)` | NO |  | `` |
| 5 | `report_id` | `NVARCHAR(120)` | YES |  | `` |
| 6 | `raw_file_id` | `BIGINT` | YES |  | `` |
| 7 | `raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 8 | `validation_stage` | `NVARCHAR(80)` | NO |  | `('post_download')` |
| 9 | `validation_status` | `NVARCHAR(80)` | NO |  | `` |
| 10 | `severity` | `NVARCHAR(50)` | NO |  | `('info')` |
| 11 | `row_count` | `INT` | YES |  | `` |
| 12 | `observed_fields_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 13 | `expected_fields_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 14 | `missing_fields_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 15 | `new_fields_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 16 | `unmapped_fields_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 17 | `requires_review` | `BIT` | NO |  | `((0))` |
| 18 | `notification_status` | `NVARCHAR(50)` | NO |  | `('not_required')` |
| 19 | `notified_at` | `DATETIME2(7)` | YES |  | `` |
| 20 | `message` | `NVARCHAR(MAX)` | YES |  | `` |
| 21 | `source_run_id` | `BIGINT` | YES |  | `` |
| 22 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_schema_validation_event_report` | NO | `NONCLUSTERED` | `source_system`, `report_type`, `marketplace_id`, `created_at` DESC |  | `` |
| `IX_amazon_schema_validation_event_review` | NO | `NONCLUSTERED` | `requires_review`, `notification_status`, `created_at` DESC |  | `` |
| `PK_amazon_schema_validation_event` | YES | `CLUSTERED` | `id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_schema_validation_event` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_schema_validation_event` |

### `dbo.amazon_settlement_transaction`

- Create date: `2026-05-16T20:29:55.693000`
- Modify date: `2026-05-17T20:42:37.050000`
- Row count: `4911`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `settlement_id` | `NVARCHAR(200)` | YES |  | `` |
| 4 | `settlement_start_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 5 | `settlement_end_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 6 | `deposit_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 7 | `total_amount` | `DECIMAL(18,4)` | YES |  | `` |
| 8 | `currency` | `NVARCHAR(10)` | YES |  | `` |
| 9 | `is_settlement_summary` | `BIT` | NO |  | `((0))` |
| 10 | `transaction_type` | `NVARCHAR(120)` | YES |  | `` |
| 11 | `order_id` | `NVARCHAR(200)` | YES |  | `` |
| 12 | `merchant_order_id` | `NVARCHAR(200)` | YES |  | `` |
| 13 | `adjustment_id` | `NVARCHAR(200)` | YES |  | `` |
| 14 | `shipment_id` | `NVARCHAR(200)` | YES |  | `` |
| 15 | `marketplace_name` | `NVARCHAR(200)` | YES |  | `` |
| 16 | `amount_type` | `NVARCHAR(120)` | YES |  | `` |
| 17 | `amount_description` | `NVARCHAR(300)` | YES |  | `` |
| 18 | `amount` | `DECIMAL(18,4)` | YES |  | `` |
| 19 | `amount_category` | `NVARCHAR(120)` | NO |  | `` |
| 20 | `profit_bucket` | `NVARCHAR(120)` | NO |  | `` |
| 21 | `fulfillment_id` | `NVARCHAR(100)` | YES |  | `` |
| 22 | `posted_date_raw` | `NVARCHAR(100)` | YES |  | `` |
| 23 | `posted_date_time_raw` | `NVARCHAR(100)` | YES |  | `` |
| 24 | `order_item_code` | `NVARCHAR(200)` | YES |  | `` |
| 25 | `merchant_order_item_id` | `NVARCHAR(200)` | YES |  | `` |
| 26 | `merchant_adjustment_item_id` | `NVARCHAR(200)` | YES |  | `` |
| 27 | `seller_sku` | `NVARCHAR(200)` | YES |  | `` |
| 28 | `quantity_purchased` | `INT` | YES |  | `` |
| 29 | `promotion_id` | `NVARCHAR(500)` | YES |  | `` |
| 30 | `source_system` | `NVARCHAR(50)` | NO |  | `('sp_api_reports')` |
| 31 | `source_report_type` | `NVARCHAR(120)` | NO |  | `` |
| 32 | `source_report_id` | `NVARCHAR(120)` | YES |  | `` |
| 33 | `source_report_request_id` | `BIGINT` | YES |  | `` |
| 34 | `source_raw_file_id` | `BIGINT` | YES |  | `` |
| 35 | `source_raw_file_path` | `NVARCHAR(1000)` | YES |  | `` |
| 36 | `source_run_id` | `BIGINT` | YES |  | `` |
| 37 | `source_row_hash` | `NVARCHAR(100)` | NO |  | `` |
| 38 | `raw_data` | `NVARCHAR(MAX)` | NO |  | `` |
| 39 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 40 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 41 | `source_row_index` | `INT` | YES |  | `` |
| 42 | `business_key_hash` | `NVARCHAR(100)` | YES |  | `` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_settlement_transaction_order_sku` | NO | `NONCLUSTERED` | `marketplace_id`, `order_id`, `seller_sku`, `amount_category`, `profit_bucket` |  | `` |
| `IX_amazon_settlement_transaction_settlement` | NO | `NONCLUSTERED` | `marketplace_id`, `settlement_id`, `is_settlement_summary`, `transaction_type` |  | `` |
| `IX_amazon_settlement_transaction_source` | NO | `NONCLUSTERED` | `source_report_id`, `source_row_hash` |  | `` |
| `PK_amazon_settlement_transaction` | YES | `CLUSTERED` | `id` |  | `` |
| `UX_amazon_settlement_transaction_business_key_hash` | YES | `NONCLUSTERED` | `business_key_hash` |  | `([business_key_hash] IS NOT NULL)` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_settlement_transaction` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_settlement_transaction` |

### `dbo.amazon_sku_cost`

- Create date: `2026-05-16T20:29:55.340000`
- Modify date: `2026-05-16T20:30:09.983000`
- Row count: `0`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `marketplace_id` | `NVARCHAR(50)` | NO |  | `` |
| 3 | `seller_sku` | `NVARCHAR(200)` | NO |  | `` |
| 4 | `asin` | `NVARCHAR(50)` | YES |  | `` |
| 5 | `product_cost` | `DECIMAL(18,4)` | NO |  | `((0))` |
| 6 | `first_mile_cost` | `DECIMAL(18,4)` | NO |  | `((0))` |
| 7 | `packaging_cost` | `DECIMAL(18,4)` | NO |  | `((0))` |
| 8 | `other_unit_cost` | `DECIMAL(18,4)` | NO |  | `((0))` |
| 9 | `currency` | `NVARCHAR(10)` | NO |  | `` |
| 10 | `effective_from` | `DATE` | NO |  | `` |
| 11 | `effective_to` | `DATE` | YES |  | `` |
| 12 | `remark` | `NVARCHAR(MAX)` | YES |  | `` |
| 13 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 14 | `updated_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_sku_cost_effective` | NO | `NONCLUSTERED` | `marketplace_id`, `seller_sku`, `effective_from`, `effective_to` |  | `` |
| `PK_amazon_sku_cost` | YES | `CLUSTERED` | `id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_sku_cost` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_sku_cost` |

### `dbo.amazon_sync_run_log`

- Create date: `2026-05-16T20:29:54.910000`
- Modify date: `2026-05-16T20:30:09.527000`
- Row count: `16`

#### Columns

| # | Column | Type | Nullable | Identity | Default |
|---:|---|---|---|---|---|
| 1 | `id` | `BIGINT` | NO | seed=1, increment=1 | `` |
| 2 | `workflow_name` | `NVARCHAR(120)` | YES |  | `` |
| 3 | `job_name` | `NVARCHAR(120)` | NO |  | `` |
| 4 | `task_type` | `NVARCHAR(80)` | YES |  | `` |
| 5 | `trigger_type` | `NVARCHAR(50)` | NO |  | `('manual')` |
| 6 | `run_mode` | `NVARCHAR(50)` | NO |  | `('local')` |
| 7 | `parent_run_id` | `BIGINT` | YES |  | `` |
| 8 | `job_execution_id` | `NVARCHAR(200)` | YES |  | `` |
| 9 | `marketplace_id` | `NVARCHAR(50)` | YES |  | `` |
| 10 | `source_system` | `NVARCHAR(50)` | YES |  | `` |
| 11 | `status` | `NVARCHAR(50)` | NO |  | `('running')` |
| 12 | `started_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |
| 13 | `finished_at` | `DATETIME2(7)` | YES |  | `` |
| 14 | `duration_ms` | `BIGINT` | YES |  | `` |
| 15 | `date_start` | `DATE` | YES |  | `` |
| 16 | `date_end` | `DATE` | YES |  | `` |
| 17 | `rows_read` | `INT` | NO |  | `((0))` |
| 18 | `rows_written` | `INT` | NO |  | `((0))` |
| 19 | `rows_skipped` | `INT` | NO |  | `((0))` |
| 20 | `rows_failed` | `INT` | NO |  | `((0))` |
| 21 | `files_created` | `INT` | NO |  | `((0))` |
| 22 | `retry_count` | `INT` | NO |  | `((0))` |
| 23 | `config_snapshot_json` | `NVARCHAR(MAX)` | YES |  | `` |
| 24 | `message` | `NVARCHAR(MAX)` | YES |  | `` |
| 25 | `error_type` | `NVARCHAR(200)` | YES |  | `` |
| 26 | `error_detail` | `NVARCHAR(MAX)` | YES |  | `` |
| 27 | `created_at` | `DATETIME2(7)` | NO |  | `(sysutcdatetime())` |

#### Indexes

| Index | Unique | Type | Key columns | Included columns | Filter |
|---|---|---|---|---|---|
| `IX_amazon_sync_run_log_job_started` | NO | `NONCLUSTERED` | `job_name`, `started_at` DESC |  | `` |
| `IX_amazon_sync_run_log_status_started` | NO | `NONCLUSTERED` | `status`, `started_at` DESC |  | `` |
| `IX_amazon_sync_run_log_workflow_started` | NO | `NONCLUSTERED` | `workflow_name`, `started_at` DESC |  | `` |
| `PK_amazon_sync_run_log` | YES | `CLUSTERED` | `id` |  | `` |

#### Key constraints

| Constraint | Type | Backing index |
|---|---|---|
| `PK_amazon_sync_run_log` | `PRIMARY_KEY_CONSTRAINT` | `PK_amazon_sync_run_log` |
