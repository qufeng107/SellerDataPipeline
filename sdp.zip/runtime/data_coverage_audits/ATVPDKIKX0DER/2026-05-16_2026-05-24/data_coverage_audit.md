# Data Coverage Audit

Marketplace: `ATVPDKIKX0DER`
Target window: `2026-05-16` to `2026-05-24`
Generated UTC: `2026-05-24T01:02:48+00:00`

## Stable coverage summary

| Stable status | Count |
|---|---:|
| `covers_stable_window` | 7 |
| `ends_before_stable_target` | 2 |
| `no_business_dates` | 1 |
| `outside_target_window` | 7 |
| `starts_after_target_start` | 2 |

## Raw target-window status summary

| Status | Count |
|---|---:|
| `has_target_window_data` | 9 |
| `no_business_dates` | 1 |
| `outside_target_window` | 7 |
| `starts_after_target_start` | 2 |

## Normalized table coverage

| Data domain | Table | Stable status | Rows | Business date range | Stable target end | Lag days | Latest business date age | Refresh cadence | Lookback | Role |
|---|---|---|---:|---|---|---:|---:|---:|---:|---|
| Ads SP campaign daily | `amazon_ads_sp_campaign_daily` | `covers_stable_window` | 36 | 2026-05-06..2026-05-22 | 2026-05-21 | 3 | 2 | 2 | 14 | weekly_context |
| Ads SP targeting daily | `amazon_ads_sp_targeting_daily` | `covers_stable_window` | 523 | 2026-03-31..2026-05-22 | 2026-05-21 | 3 | 2 | 2 | 14 | weekly_context |
| Ads SP search term daily | `amazon_ads_sp_search_term_daily` | `covers_stable_window` | 567 | 2026-04-14..2026-05-22 | 2026-05-21 | 3 | 2 | 2 | 14 | weekly_context |
| Ads SP advertised product daily | `amazon_ads_sp_advertised_product_daily` | `covers_stable_window` | 260 | 2026-03-31..2026-05-22 | 2026-05-21 | 3 | 2 | 2 | 14 | weekly_context |
| Listing snapshot | `amazon_listing_snapshot` | `ends_before_stable_target` | 12 | 2026-05-13..2026-05-20 | 2026-05-24 | 0 | 4 | 7 | 1 | weekly_snapshot |
| Inventory snapshot | `amazon_inventory_daily` | `covers_stable_window` | 15 | 2026-05-14..2026-05-24 | 2026-05-24 | 0 | 0 | 2 | 1 | weekly_snapshot |
| Sales & Traffic date daily | `amazon_sales_traffic_daily` | `covers_stable_window` | 143 | 2025-12-31..2026-05-22 | 2026-05-22 | 2 | 2 | 2 | 10 | weekly_context |
| Sales & Traffic ASIN daily | `amazon_sales_traffic_asin_daily` | `outside_target_window` | 5 | 2025-12-31..2026-05-13 | 2026-05-22 | 2 | 11 | 2 | 10 | weekly_context |
| Settlement transaction | `amazon_settlement_transaction` | `outside_target_window` | 5170 | 2026-02-06..2026-11-03 | 2026-05-24 | 0 | -163 | 7 | 60 | financial_source_of_truth |
| Orders | `amazon_order_item` | `ends_before_stable_target` | 582 | 2026-03-01..2026-05-19 | 2026-05-22 | 2 | 5 | 2 | 10 | weekly_context |
| FBA reimbursements | `amazon_fba_reimbursement` | `covers_stable_window` | 24 | 2026-01-25..2026-05-18 | 2026-05-17 | 7 | 6 | 7 | 60 | weekly_exception_context |
| FBA fee preview | `amazon_fba_fee_preview` | `starts_after_target_start` | 12 | 2026-05-17..2026-05-20 | 2026-05-24 | 0 | 4 | 7 | 1 | weekly_reference_snapshot |
| Promotion performance | `amazon_promotion_performance` | `outside_target_window` | 1 | 2026-03-23..2026-03-23 | 2026-05-22 | 2 | 62 | 2 | 30 | weekly_context |
| Promotion product performance | `amazon_promotion_product_performance` | `starts_after_target_start` | 3 | 2026-05-17..2026-05-17 | 2026-05-22 | 2 | 7 | 2 | 30 | weekly_context |
| Coupon performance | `amazon_coupon_performance` | `outside_target_window` | 2 | 2026-03-25..2026-05-13 | 2026-05-22 | 2 | 11 | 2 | 30 | weekly_context |
| Coupon ASIN | `amazon_coupon_asin` | `outside_target_window` | 4 | 2026-03-25..2026-05-13 | 2026-05-22 | 2 | 11 | 2 | 30 | weekly_context |
| Inventory ledger summary | `amazon_inventory_ledger_summary_daily` | `outside_target_window` | 150 | 2026-04-14..2026-05-13 | 2026-05-21 | 3 | 11 | 7 | 30 | weekly_exception_context |
| Inventory ledger detail | `amazon_inventory_ledger_detail` | `no_business_dates` | 207 | .. | 2026-05-21 | 3 |  | 7 | 30 | weekly_exception_context |
| SKU cost | `amazon_sku_cost` | `outside_target_window` | 7 | 2025-01-01..2025-01-01 | 2026-05-24 | 0 | 508 |  |  | internal_cost_control |

## Report request coverage

| Source | Report type | Requests | Done | Downloaded | Parsed | Requested data window | Target-overlap requests |
|---|---|---:|---:|---:|---:|---|---:|

## How to read this audit

- `covers_stable_window`: the table reaches the source-specific stable cutoff date after applying `data_window_lag_days`.
- `ends_before_stable_target`: the table has target-window data, but it does not yet reach the stable cutoff date.
- `starts_after_target_start`: the table has target-window data, but historical backfill starts after the requested start date.
- `outside_target_window`: the table has rows, but none overlap the requested target window.
- `no_rows`: the table is empty for this marketplace.
- `data_window_lag_days` prevents today/yesterday from being treated as required final data for volatile sources.
- Analysis/report outputs remain weekly at minimum, even when data refresh runs every 1-2 days.
- Snapshot-style sources such as Listing, Inventory, and FBA Fee Preview are not expected to contain every calendar day.
