# Data Coverage Audit

Marketplace: `ATVPDKIKX0DER`
Target window: `2026-01-01` to `2026-05-18`
Generated UTC: `2026-05-18T22:44:48+00:00`

## Status summary

| Status | Count |
|---|---:|
| `no_business_dates` | 1 |
| `outside_target_window` | 1 |
| `starts_after_target_start` | 17 |

## Normalized table coverage

| Data domain | Table | Status | Rows | Business date range | Target rows | Latest business date age | Entities | Date semantics |
|---|---|---|---:|---|---:|---:|---:|---|
| Ads SP campaign daily | `amazon_ads_sp_campaign_daily` | `starts_after_target_start` | 8 | 2026-05-12..2026-05-15 | 8 | 3 | 2 | report_date |
| Ads SP targeting daily | `amazon_ads_sp_targeting_daily` | `starts_after_target_start` | 99 | 2026-05-12..2026-05-15 | 99 | 3 | 27 | report_date |
| Ads SP search term daily | `amazon_ads_sp_search_term_daily` | `starts_after_target_start` | 61 | 2026-05-12..2026-05-15 | 61 | 3 | 45 | report_date |
| Ads SP advertised product daily | `amazon_ads_sp_advertised_product_daily` | `starts_after_target_start` | 32 | 2026-05-12..2026-05-15 | 32 | 3 | 4 | report_date |
| Listing snapshot | `amazon_listing_snapshot` | `starts_after_target_start` | 6 | 2026-05-13..2026-05-13 | 6 | 5 | 6 | snapshot_date |
| Inventory snapshot | `amazon_inventory_daily` | `starts_after_target_start` | 5 | 2026-05-14..2026-05-14 | 5 | 4 | 5 | snapshot_date |
| Sales & Traffic date daily | `amazon_sales_traffic_daily` | `starts_after_target_start` | 6 | 2026-05-07..2026-05-12 | 6 | 6 | 0 | report_date |
| Sales & Traffic ASIN daily | `amazon_sales_traffic_asin_daily` | `starts_after_target_start` | 1 | 2026-05-07..2026-05-07 | 1 | 11 | 1 | report_start_date/report_end_date |
| Settlement transaction | `amazon_settlement_transaction` | `starts_after_target_start` | 4911 | 2026-02-06..2026-11-03 | 4899 | -169 | 7 | posted_date/posted_date_time/deposit_date |
| Orders | `amazon_order_item` | `starts_after_target_start` | 112 | 2026-04-14..2026-05-13 | 112 | 5 | 5 | purchase_date |
| FBA reimbursements | `amazon_fba_reimbursement` | `starts_after_target_start` | 19 | 2026-02-13..2026-05-12 | 19 | 6 | 3 | approval_date |
| FBA fee preview | `amazon_fba_fee_preview` | `starts_after_target_start` | 8 | 2026-05-17..2026-05-17 | 8 | 1 | 4 | created_at snapshot date |
| Promotion performance | `amazon_promotion_performance` | `starts_after_target_start` | 1 | 2026-03-23..2026-03-23 | 1 | 56 | 1 | start_date_time/created_date_time |
| Promotion product performance | `amazon_promotion_product_performance` | `starts_after_target_start` | 3 | 2026-05-17..2026-05-17 | 3 | 1 | 3 | created_at snapshot date |
| Coupon performance | `amazon_coupon_performance` | `starts_after_target_start` | 2 | 2026-03-25..2026-05-13 | 2 | 5 | 2 | start_date_time |
| Coupon ASIN | `amazon_coupon_asin` | `starts_after_target_start` | 4 | 2026-03-25..2026-05-13 | 4 | 5 | 4 | start_date_time |
| Inventory ledger summary | `amazon_inventory_ledger_summary_daily` | `starts_after_target_start` | 150 | 2026-04-14..2026-05-13 | 150 | 5 | 5 | ledger_date |
| Inventory ledger detail | `amazon_inventory_ledger_detail` | `no_business_dates` | 207 | .. | 0 |  | 5 | date_time |
| SKU cost | `amazon_sku_cost` | `outside_target_window` | 4 | 2025-01-01..2025-01-01 | 0 | 502 | 4 | effective_from |

## Report request coverage

| Source | Report type | Requests | Done | Downloaded | Parsed | Requested data window | Target-overlap requests |
|---|---|---:|---:|---:|---:|---|---:|

## How to read this audit

- `has_target_window_data`: the table has rows in the requested target window.
- `starts_after_target_start`: the table has rows in the target window, but the earliest business date is after the requested start date.
- `outside_target_window`: the table has rows, but none overlap the requested target window.
- `no_rows`: the table is empty for this marketplace.
- Snapshot-style sources such as Listing, Inventory, FBA Fee Preview, and Promotion product details are not expected to contain every calendar day.
