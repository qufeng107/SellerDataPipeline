# Data Coverage Audit

Marketplace: `ATVPDKIKX0DER`
Target window: `2026-01-01` to `2026-05-19`
Generated UTC: `2026-05-18T23:45:00+00:00`

## Stable coverage summary

| Stable status | Count |
|---|---:|
| `no_business_dates` | 1 |
| `outside_target_window` | 1 |
| `starts_after_target_start` | 17 |

## Raw target-window status summary

| Status | Count |
|---|---:|
| `no_business_dates` | 1 |
| `outside_target_window` | 1 |
| `starts_after_target_start` | 17 |

## Normalized table coverage

| Data domain | Table | Stable status | Rows | Business date range | Stable target end | Lag days | Latest business date age | Refresh cadence | Lookback | Role |
|---|---|---|---:|---|---|---:|---:|---:|---:|---|
| Ads SP campaign daily | `amazon_ads_sp_campaign_daily` | `starts_after_target_start` | 8 | 2026-05-12..2026-05-15 | 2026-05-16 | 3 | 4 | 2 | 14 | weekly_context |
| Ads SP targeting daily | `amazon_ads_sp_targeting_daily` | `starts_after_target_start` | 99 | 2026-05-12..2026-05-15 | 2026-05-16 | 3 | 4 | 2 | 14 | weekly_context |
| Ads SP search term daily | `amazon_ads_sp_search_term_daily` | `starts_after_target_start` | 61 | 2026-05-12..2026-05-15 | 2026-05-16 | 3 | 4 | 2 | 14 | weekly_context |
| Ads SP advertised product daily | `amazon_ads_sp_advertised_product_daily` | `starts_after_target_start` | 32 | 2026-05-12..2026-05-15 | 2026-05-16 | 3 | 4 | 2 | 14 | weekly_context |
| Listing snapshot | `amazon_listing_snapshot` | `starts_after_target_start` | 6 | 2026-05-13..2026-05-13 | 2026-05-19 | 0 | 6 | 7 | 1 | weekly_snapshot |
| Inventory snapshot | `amazon_inventory_daily` | `starts_after_target_start` | 5 | 2026-05-14..2026-05-14 | 2026-05-19 | 0 | 5 | 2 | 1 | weekly_snapshot |
| Sales & Traffic date daily | `amazon_sales_traffic_daily` | `starts_after_target_start` | 6 | 2026-05-07..2026-05-12 | 2026-05-17 | 2 | 7 | 2 | 10 | weekly_context |
| Sales & Traffic ASIN daily | `amazon_sales_traffic_asin_daily` | `starts_after_target_start` | 1 | 2026-05-07..2026-05-07 | 2026-05-17 | 2 | 12 | 2 | 10 | weekly_context |
| Settlement transaction | `amazon_settlement_transaction` | `starts_after_target_start` | 4911 | 2026-02-06..2026-11-03 | 2026-05-19 | 0 | -168 | 7 | 60 | financial_source_of_truth |
| Orders | `amazon_order_item` | `starts_after_target_start` | 112 | 2026-04-14..2026-05-13 | 2026-05-17 | 2 | 6 | 2 | 10 | weekly_context |
| FBA reimbursements | `amazon_fba_reimbursement` | `starts_after_target_start` | 19 | 2026-02-13..2026-05-12 | 2026-05-12 | 7 | 7 | 7 | 60 | weekly_exception_context |
| FBA fee preview | `amazon_fba_fee_preview` | `starts_after_target_start` | 8 | 2026-05-17..2026-05-17 | 2026-05-19 | 0 | 2 | 7 | 1 | weekly_reference_snapshot |
| Promotion performance | `amazon_promotion_performance` | `starts_after_target_start` | 1 | 2026-03-23..2026-03-23 | 2026-05-17 | 2 | 57 | 2 | 30 | weekly_context |
| Promotion product performance | `amazon_promotion_product_performance` | `starts_after_target_start` | 3 | 2026-05-17..2026-05-17 | 2026-05-17 | 2 | 2 | 2 | 30 | weekly_context |
| Coupon performance | `amazon_coupon_performance` | `starts_after_target_start` | 2 | 2026-03-25..2026-05-13 | 2026-05-17 | 2 | 6 | 2 | 30 | weekly_context |
| Coupon ASIN | `amazon_coupon_asin` | `starts_after_target_start` | 4 | 2026-03-25..2026-05-13 | 2026-05-17 | 2 | 6 | 2 | 30 | weekly_context |
| Inventory ledger summary | `amazon_inventory_ledger_summary_daily` | `starts_after_target_start` | 150 | 2026-04-14..2026-05-13 | 2026-05-16 | 3 | 6 | 7 | 30 | weekly_exception_context |
| Inventory ledger detail | `amazon_inventory_ledger_detail` | `no_business_dates` | 207 | .. | 2026-05-16 | 3 |  | 7 | 30 | weekly_exception_context |
| SKU cost | `amazon_sku_cost` | `outside_target_window` | 4 | 2025-01-01..2025-01-01 | 2026-05-19 | 0 | 503 |  |  | internal_cost_control |

## Report request coverage

| Source | Report type | Requests | Done | Downloaded | Parsed | Requested data window | Target-overlap requests |
|---|---|---:|---:|---:|---:|---|---:|

## How to read this audit

- `covers_stable_window`: the table reaches the source-specific stable cutoff date after applying `data_window_lag_days`.
- `ends_before_stable_target`: the table has target-window data, but it does not yet reach the stable cutoff date.
- `starts_after_target_start`: the table has target-window data, but historical backfill starts after the requested start date.
- `outside_target_window`: the table has rows, but none overlap the requested target window.
- `no_rows`: the table is empty for this marketplace.
- `data_window_lag_days` prevents today/yesterday from being treated as required final data for volatile sources.
- Analysis/report outputs remain weekly at minimum, even when data refresh runs every 1-2 days.
- Snapshot-style sources such as Listing, Inventory, and FBA Fee Preview are not expected to contain every calendar day.
