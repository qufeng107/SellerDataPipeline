# Profit Preview — ATVPDKIKX0DER

Period: `2026-03-01` to `2026-03-31`
Status: `ok`
Policy: `Settlement-led Financial Profit v1.0`
Currency: `USD`

## Summary

| Metric | Value |
|---|---:|
| Settlement rows | 1899 |
| Settlement net amount | USD 2015.42 |
| Product-sales units used for COGS | 353 |
| Product-sales amount | USD 7843.43 |
| Internal COGS | USD 1477.55 |
| Estimated operating profit | USD 537.87 |

## Settlement bucket totals

| Profit bucket | Amount |
|---|---:|
| `advertising_cost` | USD -2903.93 |
| `amazon_fee` | USD -106.51 |
| `amazon_fee_refund` | USD 2.40 |
| `fba_fee` | USD -1500.22 |
| `fba_storage_fee` | USD -26.56 |
| `promotion_cost` | USD -220.07 |
| `promotion_fee` | USD -72.11 |
| `refund` | USD -1192.09 |
| `reimbursement` | USD 62.96 |
| `revenue` | USD 7971.31 |
| `tax_passthrough` | USD 0.24 |

## SKU detail

| SKU | Units | Settlement net | COGS | Profit after COGS | Status |
|---|---:|---:|---:|---:|---|
| `A2-GA56-J6ZC` | 31 | USD 522.69 | USD 129.27 | USD 393.42 | `ok` |
| `EU-IB28-EECW` | 78 | USD 1016.30 | USD 325.26 | USD 691.04 | `ok` |
| `HU-4XAJ-PYLD` | 2 | USD 48.64 | USD 13.88 | USD 34.76 | `ok` |
| `SC-9HC3-5TFL` | 34 | USD 569.71 | USD 141.78 | USD 427.93 | `ok` |
| `W1-L6JP-TECU` | 208 | USD 2934.50 | USD 867.36 | USD 2067.14 | `ok` |

## Operational context (not financial source of truth)

| Metric | Value |
|---|---:|
| Orders | 0 |
| Order item rows | 0 |
| Ordered units | 0 |
| Ordered item sales | 0.00 |
| Ads cost | USD 0.00 |
| Ads sales 7d | USD 0.00 |
| Ads clicks | 0 |
| Ads impressions | 0 |
| Sales & Traffic units ordered | 369 |
| Sales & Traffic sales | USD 8086.52 |
| Sales & Traffic sessions | 5442 |

## Warnings / review notes

- Preview policy: Settlement is the financial source of truth; Orders/Ads/Sales data are shown only as operational context.
