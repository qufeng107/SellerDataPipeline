# Profit Preview — ATVPDKIKX0DER

Period: `2026-02-01` to `2026-02-28`
Status: `ok`
Policy: `Settlement-led Financial Profit v1.0`
Currency: `USD`

## Summary

| Metric | Value |
|---|---:|
| Settlement rows | 1564 |
| Settlement net amount | USD 1250.11 |
| Product-sales units used for COGS | 281 |
| Product-sales amount | USD 5836.34 |
| Internal COGS | USD 1171.77 |
| Estimated operating profit | USD 78.34 |

## Settlement bucket totals

| Profit bucket | Amount |
|---|---:|
| `advertising_cost` | USD -2005.43 |
| `amazon_fee` | USD -234.19 |
| `amazon_fee_refund` | USD 28.71 |
| `fba_fee` | USD -1278.16 |
| `fba_storage_fee` | USD -29.45 |
| `promotion_cost` | USD -471.58 |
| `promotion_fee` | USD -37.45 |
| `reconciliation` | USD 0.00 |
| `refund` | USD -613.59 |
| `reimbursement` | USD -22.47 |
| `revenue` | USD 5913.72 |
| `tax_passthrough` | USD 0.00 |

## SKU detail

| SKU | Units | Settlement net | COGS | Profit after COGS | Status |
|---|---:|---:|---:|---:|---|
| `A2-GA56-J6ZC` | 18 | USD 245.18 | USD 75.06 | USD 170.12 | `ok` |
| `EU-IB28-EECW` | 66 | USD 847.02 | USD 275.22 | USD 571.80 | `ok` |
| `SC-9HC3-5TFL` | 38 | USD 561.97 | USD 158.46 | USD 403.51 | `ok` |
| `W1-L6JP-TECU` | 159 | USD 1841.88 | USD 663.03 | USD 1178.85 | `ok` |

## Operational context (not financial source of truth)

| Metric | Value |
|---|---:|
| Orders | 0 |
| Order item rows | 0 |
| Ordered units | 0 |
| Ordered item sales | 0.00 |
| Ads cost | USD 0.00 |
| Ads sales 7d | USD 0.00 |
| Ads clicks | 0 |
| Ads impressions | 0 |
| Sales & Traffic units ordered | 342 |
| Sales & Traffic sales | USD 6877.70 |
| Sales & Traffic sessions | 4972 |

## Warnings / review notes

- Preview policy: Settlement is the financial source of truth; Orders/Ads/Sales data are shown only as operational context.
