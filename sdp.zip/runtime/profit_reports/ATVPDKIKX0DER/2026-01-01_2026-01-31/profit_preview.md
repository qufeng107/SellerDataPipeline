# Profit Preview — ATVPDKIKX0DER

Period: `2026-01-01` to `2026-01-31`
Status: `no_data`
Policy: `Settlement-led Financial Profit v1.0`
Currency: `-`

## Summary

| Metric | Value |
|---|---:|
| Settlement rows | 0 |
| Settlement net amount | 0.00 |
| Product-sales units used for COGS | 0 |
| Product-sales amount | 0.00 |
| Internal COGS | 0.00 |
| Estimated operating profit | 0.00 |

## Settlement bucket totals

| Profit bucket | Amount |
|---|---:|

## SKU detail

| SKU | Units | Settlement net | COGS | Profit after COGS | Status |
|---|---:|---:|---:|---:|---|

## Operational context (not financial source of truth)

| Metric | Value |
|---|---:|
| Orders | 0 |
| Order item rows | 0 |
| Ordered units | 0 |
| Ordered item sales | 0.00 |
| Ads cost | 0.00 |
| Ads sales 7d | 0.00 |
| Ads clicks | 0 |
| Ads impressions | 0 |
| Sales & Traffic units ordered | 447 |
| Sales & Traffic sales | 9612.90 |
| Sales & Traffic sessions | 7402 |

## Warnings / review notes

- No settlement rows found for this marketplace/date window.
- Preview policy: Settlement is the financial source of truth; Orders/Ads/Sales data are shown only as operational context.
