# Profit Preview — ATVPDKIKX0DER

Period: `2026-05-01` to `2026-05-17`
Status: `ok`
Policy: `Settlement-led Financial Profit v1.0`
Currency: `USD`

## Summary

| Metric | Value |
|---|---:|
| Settlement rows | 264 |
| Settlement net amount | USD 140.97 |
| Product-sales units used for COGS | 50 |
| Product-sales amount | USD 1019.32 |
| Internal COGS | USD 208.50 |
| Estimated operating profit | USD -67.53 |

## Settlement bucket totals

| Profit bucket | Amount |
|---|---:|
| `advertising_cost` | USD -483.71 |
| `amazon_fee` | USD -27.33 |
| `fba_fee` | USD -178.20 |
| `fba_storage_fee` | USD -36.79 |
| `liquidation` | USD 4.82 |
| `liquidation_fee` | USD -2.47 |
| `promotion_cost` | USD -23.78 |
| `refund` | USD -193.98 |
| `reimbursement` | USD 38.10 |
| `revenue` | USD 1044.31 |
| `tax_passthrough` | USD 0.00 |
| `unknown` | USD 0.00 |

## SKU detail

| SKU | Units | Settlement net | COGS | Profit after COGS | Status |
|---|---:|---:|---:|---:|---|
| `A2-GA56-J6ZC` | 1 | USD 21.95 | USD 4.17 | USD 17.78 | `ok` |
| `EU-IB28-EECW` | 6 | USD 79.70 | USD 25.02 | USD 54.68 | `ok` |
| `SC-9HC3-5TFL` | 5 | USD 69.75 | USD 20.85 | USD 48.90 | `ok` |
| `W1-L6JP-TECU` | 31 | USD 513.50 | USD 129.27 | USD 384.23 | `ok` |
| `X004WU7IEL` | 7 | USD 2.35 | USD 29.19 | USD -26.84 | `ok` |

## Operational context (not financial source of truth)

| Metric | Value |
|---|---:|
| Orders | 47 |
| Order item rows | 52 |
| Ordered units | 55 |
| Ordered item sales | USD 1263.38 |
| Ads cost | USD 208.55 |
| Ads sales 7d | USD 377.00 |
| Ads clicks | 336 |
| Ads impressions | 101281 |
| Sales & Traffic units ordered | 51 |
| Sales & Traffic sales | USD 1243.38 |
| Sales & Traffic sessions | 1033 |

## Warnings / review notes

- Preview policy: Settlement is the financial source of truth; Orders/Ads/Sales data are shown only as operational context.
