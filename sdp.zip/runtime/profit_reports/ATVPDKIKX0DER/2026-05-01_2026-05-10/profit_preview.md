# Profit Preview — ATVPDKIKX0DER

Period: `2026-05-01` to `2026-05-10`
Status: `ok`
Policy: `Settlement-led Financial Profit v1.0`
Currency: `USD`

## Summary

| Metric | Value |
|---|---:|
| Settlement rows | 6 |
| Settlement net amount | USD 20.95 |
| Product-sales units used for COGS | 1 |
| Product-sales amount | USD 25.00 |
| Internal COGS | USD 4.17 |
| Estimated operating profit | USD 16.78 |

## Settlement bucket totals

| Profit bucket | Amount |
|---|---:|
| `fba_fee` | USD -4.05 |
| `promotion_cost` | USD -1.00 |
| `revenue` | USD 26.00 |
| `tax_passthrough` | USD 0.00 |

## SKU detail

| SKU | Units | Settlement net | COGS | Profit after COGS | Status |
|---|---:|---:|---:|---:|---|
| `SC-9HC3-5TFL` | 1 | USD 20.95 | USD 4.17 | USD 16.78 | `ok` |

## Operational context (not financial source of truth)

| Metric | Value |
|---|---:|
| Orders | 28 |
| Order item rows | 29 |
| Ordered units | 31 |
| Ordered item sales | USD 661.00 |
| Ads cost | USD 0.00 |
| Ads sales 7d | USD 0.00 |
| Ads clicks | 0 |
| Ads impressions | 0 |
| Sales & Traffic units ordered | 11 |
| Sales & Traffic sales | USD 275.00 |
| Sales & Traffic sessions | 228 |

## Warnings / review notes

- Preview policy: Settlement is the financial source of truth; Orders/Ads/Sales data are shown only as operational context.
