# Profit Preview — ATVPDKIKX0DER

Period: `2026-04-01` to `2026-04-30`
Status: `ok`
Policy: `Settlement-led Financial Profit v1.0`
Currency: `USD`

## Summary

| Metric | Value |
|---|---:|
| Settlement rows | 1430 |
| Settlement net amount | USD 1853.15 |
| Product-sales units used for COGS | 258 |
| Product-sales amount | USD 6241.84 |
| Internal COGS | USD 1075.86 |
| Estimated operating profit | USD 777.29 |

## Settlement bucket totals

| Profit bucket | Amount |
|---|---:|
| `advertising_cost` | USD -2003.85 |
| `amazon_fee` | USD -420.63 |
| `amazon_fee_refund` | USD 16.31 |
| `fba_fee` | USD -1135.83 |
| `fba_storage_fee` | USD -33.44 |
| `liquidation` | USD 1.49 |
| `liquidation_fee` | USD -0.73 |
| `promotion_cost` | USD -315.27 |
| `promotion_fee` | USD -166.17 |
| `refund` | USD -537.65 |
| `reimbursement` | USD 101.28 |
| `revenue` | USD 6347.64 |
| `tax_passthrough` | USD 0.00 |

## SKU detail

| SKU | Units | Settlement net | COGS | Profit after COGS | Status |
|---|---:|---:|---:|---:|---|
| `A2-GA56-J6ZC` | 19 | USD 298.57 | USD 79.23 | USD 219.34 | `ok` |
| `EU-IB28-EECW` | 38 | USD 758.83 | USD 158.46 | USD 600.37 | `ok` |
| `HU-4XAJ-PYLD` | 0 | USD -6.38 | USD 0.00 | USD -6.38 | `ok` |
| `SC-9HC3-5TFL` | 33 | USD 618.19 | USD 137.61 | USD 480.58 | `ok` |
| `W1-L6JP-TECU` | 166 | USD 2508.27 | USD 692.22 | USD 1816.05 | `ok` |
| `X004WU783R` | 1 | USD 0.52 | USD 4.17 | USD -3.65 | `ok` |
| `X004WU7IEL` | 1 | USD 0.24 | USD 4.17 | USD -3.93 | `ok` |

## Operational context (not financial source of truth)

| Metric | Value |
|---|---:|
| Orders | 73 |
| Order item rows | 74 |
| Ordered units | 222 |
| Ordered item sales | USD 1707.40 |
| Ads cost | USD 0.00 |
| Ads sales 7d | USD 0.00 |
| Ads clicks | 0 |
| Ads impressions | 0 |
| Sales & Traffic units ordered | 163 |
| Sales & Traffic sales | USD 3913.40 |
| Sales & Traffic sessions | 3290 |

## Warnings / review notes

- Preview policy: Settlement is the financial source of truth; Orders/Ads/Sales data are shown only as operational context.
