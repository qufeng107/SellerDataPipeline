# spAdvertisedProduct schema validation

| Item | Value |
|---|---|
| source_system | `amazon_ads` |
| report_type | `spAdvertisedProduct` |
| marketplace_id | `3917953989967300` |
| raw_file_path | `reports\raw\amazon_ads\3917953989967300\spAdvertisedProduct\2026-05-15\b6754b6b-482b-4169-8fe3-86e0af5065b3.json` |
| row_count | `32` |
| status | `ok` |
| severity | `info` |
| message | Observed report fields match the expected schema. |

## Observed fields

`adGroupId`, `adGroupName`, `advertisedAsin`, `advertisedSku`, `campaignId`, `campaignName`, `clicks`, `cost`, `date`, `impressions`, `purchases7d`, `sales7d`, `unitsSoldClicks7d`

## Expected fields

`adGroupId`, `adGroupName`, `advertisedAsin`, `advertisedSku`, `campaignId`, `campaignName`, `clicks`, `cost`, `date`, `impressions`, `purchases7d`, `sales7d`, `unitsSoldClicks7d`

## Differences

- Missing expected fields: -
- New/unexpected fields: -
- Unmapped fields: -
