# spTargeting schema validation

| Item | Value |
|---|---|
| source_system | `amazon_ads` |
| report_type | `spTargeting` |
| marketplace_id | `3917953989967300` |
| raw_file_path | `reports\raw\amazon_ads\3917953989967300\spTargeting\2026-05-15\c89e0e82-be20-468d-8ec7-884a1d623e9f.json` |
| row_count | `99` |
| status | `ok` |
| severity | `info` |
| message | Observed report fields match the expected schema. |

## Observed fields

`adGroupId`, `adGroupName`, `campaignId`, `campaignName`, `clicks`, `cost`, `date`, `impressions`, `keyword`, `keywordId`, `matchType`, `purchases7d`, `sales7d`, `targeting`, `unitsSoldClicks7d`

## Expected fields

`adGroupId`, `adGroupName`, `campaignId`, `campaignName`, `clicks`, `cost`, `date`, `impressions`, `keyword`, `keywordId`, `matchType`, `purchases7d`, `sales7d`, `targeting`, `unitsSoldClicks7d`

## Differences

- Missing expected fields: -
- New/unexpected fields: -
- Unmapped fields: -
