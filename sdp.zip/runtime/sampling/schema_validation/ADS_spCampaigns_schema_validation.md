# spCampaigns schema validation

| Item | Value |
|---|---|
| source_system | `amazon_ads` |
| report_type | `spCampaigns` |
| marketplace_id | `3917953989967300` |
| raw_file_path | `reports\raw\amazon_ads\3917953989967300\spCampaigns\2026-05-15\5dc8e80b-72cc-4e37-864f-e877b7f90e5c.json` |
| row_count | `8` |
| status | `ok` |
| severity | `info` |
| message | Observed report fields match the expected schema. |

## Observed fields

`campaignId`, `campaignName`, `campaignStatus`, `clicks`, `cost`, `date`, `impressions`, `purchases7d`, `sales7d`, `unitsSoldClicks7d`

## Expected fields

`campaignId`, `campaignName`, `campaignStatus`, `clicks`, `cost`, `date`, `impressions`, `purchases7d`, `sales7d`, `unitsSoldClicks7d`

## Differences

- Missing expected fields: -
- New/unexpected fields: -
- Unmapped fields: -
