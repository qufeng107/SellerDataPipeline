# spPurchasedProduct schema validation

| Item | Value |
|---|---|
| source_system | `amazon_ads` |
| report_type | `spPurchasedProduct` |
| marketplace_id | `3917953989967300` |
| raw_file_path | `reports\raw\amazon_ads\3917953989967300\spPurchasedProduct\2026-05-15\7ee85e28-5800-4095-8f7f-d111e70445c1.json` |
| row_count | `0` |
| status | `empty_report` |
| severity | `info` |
| message | Downloaded report is empty. Keep the raw file and do not infer table columns from this sample alone. |

## Observed fields

-

## Expected fields

`adGroupId`, `adGroupName`, `advertisedAsin`, `advertisedSku`, `campaignId`, `campaignName`, `date`, `purchasedAsin`, `purchases7d`, `sales7d`, `unitsSoldClicks7d`

## Differences

- Missing expected fields: `adGroupId`, `adGroupName`, `advertisedAsin`, `advertisedSku`, `campaignId`, `campaignName`, `date`, `purchasedAsin`, `purchases7d`, `sales7d`, `unitsSoldClicks7d`
- New/unexpected fields: -
- Unmapped fields: -
