# spSearchTerm schema validation

| Item | Value |
|---|---|
| source_system | `amazon_ads` |
| report_type | `spSearchTerm` |
| marketplace_id | `3917953989967300` |
| raw_file_path | `reports\raw\amazon_ads\3917953989967300\spSearchTerm\2026-05-15\4c38fa3c-8595-40c3-8e9f-2c52e90641a9.json` |
| row_count | `61` |
| status | `ok` |
| severity | `info` |
| message | Observed report fields match the expected schema. |

## Observed fields

`adGroupId`, `adGroupName`, `campaignId`, `campaignName`, `clicks`, `cost`, `date`, `impressions`, `keyword`, `keywordId`, `matchType`, `purchases7d`, `sales7d`, `searchTerm`, `targeting`, `unitsSoldClicks7d`

## Expected fields

`adGroupId`, `adGroupName`, `campaignId`, `campaignName`, `clicks`, `cost`, `date`, `impressions`, `keyword`, `keywordId`, `matchType`, `purchases7d`, `sales7d`, `searchTerm`, `targeting`, `unitsSoldClicks7d`

## Differences

- Missing expected fields: -
- New/unexpected fields: -
- Unmapped fields: -
